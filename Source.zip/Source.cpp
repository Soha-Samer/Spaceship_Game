#include "Angel.h"
#include "Sphere.h"
#include <glm/glm.hpp>
#include <glm/ext.hpp>

Sphere sphere1(0.5f);
Sphere sphere2(0.5f);
Sphere sphere3(0.5f);
Sphere sphere4(0.5f);
Sphere sphere5(0.5f);
Sphere sphere6(0.5f);
Sphere sphere7(0.5f);
Sphere sphere8(0.5f);
Sphere sphere9(0.5f);
Sphere sphere10(0.5f);



GLuint vao, vbo1, vbo2, ibo1, ibo2, vbo3, vbo4, ibo3, ibo4, vbo5, vbo6, ibo5, ibo6, vbo7, vbo8, ibo7, ibo8, vbo9, vbo10, ibo9, ibo10, vPosition, transAttrib;
glm::mat4 trans;
float translate = 0.f, scale = 0.f;
float factor = 0.0005;
float rotatex = 0;


// OpenGL initialization
void init()

{


    // Create a vertex array object


    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);




    // Create and initialize a vertex buffer object vbo1


    glGenBuffers(1, &vbo1);
    glBindBuffer(GL_ARRAY_BUFFER, vbo1);
    glBufferData(GL_ARRAY_BUFFER, sphere1.getInterleavedVertexSize(), sphere1.getInterleavedVertices(), GL_STATIC_DRAW);


    glGenBuffers(1, &vbo3);
    glBindBuffer(GL_ARRAY_BUFFER, vbo3);
    glBufferData(GL_ARRAY_BUFFER, sphere3.getInterleavedVertexSize(), sphere3.getInterleavedVertices(), GL_STATIC_DRAW);

    glGenBuffers(1, &vbo4);
    glBindBuffer(GL_ARRAY_BUFFER, vbo4);
    glBufferData(GL_ARRAY_BUFFER, sphere4.getInterleavedVertexSize(), sphere4.getInterleavedVertices(), GL_STATIC_DRAW);

    glGenBuffers(1, &vbo5);
    glBindBuffer(GL_ARRAY_BUFFER, vbo5);
    glBufferData(GL_ARRAY_BUFFER, sphere5.getInterleavedVertexSize(), sphere5.getInterleavedVertices(), GL_STATIC_DRAW);

    glGenBuffers(1, &vbo6);
    glBindBuffer(GL_ARRAY_BUFFER, vbo6);
    glBufferData(GL_ARRAY_BUFFER, sphere6.getInterleavedVertexSize(), sphere6.getInterleavedVertices(), GL_STATIC_DRAW);

    glGenBuffers(1, &vbo7);
    glBindBuffer(GL_ARRAY_BUFFER, vbo7);
    glBufferData(GL_ARRAY_BUFFER, sphere7.getInterleavedVertexSize(), sphere7.getInterleavedVertices(), GL_STATIC_DRAW);

    glGenBuffers(1, &vbo8);
    glBindBuffer(GL_ARRAY_BUFFER, vbo8);
    glBufferData(GL_ARRAY_BUFFER, sphere8.getInterleavedVertexSize(), sphere8.getInterleavedVertices(), GL_STATIC_DRAW);

    glGenBuffers(1, &vbo9);
    glBindBuffer(GL_ARRAY_BUFFER, vbo9);
    glBufferData(GL_ARRAY_BUFFER, sphere9.getInterleavedVertexSize(), sphere9.getInterleavedVertices(), GL_STATIC_DRAW);

    glGenBuffers(1, &vbo10);
    glBindBuffer(GL_ARRAY_BUFFER, vbo10);
    glBufferData(GL_ARRAY_BUFFER, sphere10.getInterleavedVertexSize(), sphere10.getInterleavedVertices(), GL_STATIC_DRAW);


    // Create and initialize an index buffer object ibo1

    glGenBuffers(1, &ibo1);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo1);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere1.getIndexSize(), sphere1.getIndices(), GL_STATIC_DRAW);


    glGenBuffers(1, &ibo3);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo3);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere3.getIndexSize(), sphere3.getIndices(), GL_STATIC_DRAW);


    glGenBuffers(1, &ibo4);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo4);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere4.getIndexSize(), sphere4.getIndices(), GL_STATIC_DRAW);



    glGenBuffers(1, &ibo5);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo5);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere5.getIndexSize(), sphere5.getIndices(), GL_STATIC_DRAW);


    glGenBuffers(1, &ibo6);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo6);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere6.getIndexSize(), sphere6.getIndices(), GL_STATIC_DRAW);


    glGenBuffers(1, &ibo7);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo7);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere7.getIndexSize(), sphere7.getIndices(), GL_STATIC_DRAW);


    glGenBuffers(1, &ibo8);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo8);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere8.getIndexSize(), sphere8.getIndices(), GL_STATIC_DRAW);


    glGenBuffers(1, &ibo9);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo9);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere9.getIndexSize(), sphere9.getIndices(), GL_STATIC_DRAW);


    glGenBuffers(1, &ibo10);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo10);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere10.getIndexSize(), sphere10.getIndices(), GL_STATIC_DRAW);



    // Create and initialize a vertex buffer object vbo2

    glGenBuffers(1, &vbo2);
    glBindBuffer(GL_ARRAY_BUFFER, vbo2);
    glBufferData(GL_ARRAY_BUFFER, sphere2.getInterleavedVertexSize(), sphere2.getInterleavedVertices(), GL_STATIC_DRAW);





    // Create and initialize a index buffer object ibo2


    glGenBuffers(1, &ibo2);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo2);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere2.getIndexSize(), sphere2.getIndices(), GL_STATIC_DRAW);




    // Load shaders and use the resulting shader program
    GLuint program = InitShader("vshader.glsl", "fshader.glsl");
    glUseProgram(program);



    // set up vertex arrays

    vPosition = glGetAttribLocation(program, "vertexPosition");
    glEnableVertexAttribArray(vPosition);

    transAttrib = glGetUniformLocation(program, "trans");

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0, 0.0, 0.0, 0.0);

    // get the location of the trans matrix from the shader

}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //bind the vbo and send the data to vposition in the code

    glBindBuffer(GL_ARRAY_BUFFER, vbo1);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo1);
    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere1.getInterleavedStride(), BUFFER_OFFSET(0));


    // intialize identity matrix for the trans

    trans = glm::mat4(1.0f);
    trans = glm::translate(trans, glm::vec3(0.0f, 0.0f, 0.0f));
    trans = glm::scale(trans, glm::vec3(0.70f, 0.70f, 0.70f));
    trans = glm::rotate(trans, translate, glm::vec3(0.0, 1.0, 0.0));


     glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));     //send the trans matrix to the shader

  //  glDrawElements(GL_TRIANGLES, sphere1.getIndexCount(), GL_UNSIGNED_INT, (void*)0);   // Finally, draw the sphere



    //Do the same steps above for vbo2, you can use the same trans matrix
    trans = glm::mat4(1.0f);
    trans = glm::rotate(trans, translate, glm::vec3(0.0f, 1.0f, 0.0f));
    trans = glm::translate(trans, glm::vec3(0.90f, 0.0f, 0.0f));
   // trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
   // trans = glm::rotate(trans, translate, glm::vec3(0.0f, 1.0f, 0.0f));

   // glm::vec3 color(1.0f, 0.5f, 0.31f);
    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));

    glDrawElements(GL_TRIANGLES, sphere2.getIndexCount(), GL_UNSIGNED_INT, (void*)0);   // Finally, draw the sphere
//
//
// 
// 
// 
// 
// 
// 
//
//    glBindBuffer(GL_ARRAY_BUFFER, vbo2);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo2);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere2.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//    //rest of planets
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.80f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.93f, 0.0f, 0.1f));
//
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere3.getIndexCount(), GL_UNSIGNED_INT, (void*)0);  
//
//
//
//    glBindBuffer(GL_ARRAY_BUFFER, vbo3);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo3);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere3.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//    //
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.69f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.0, 0.0, 1.0));
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere4.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo4);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo4);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere4.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//    //
//
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.58f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.0, 0.0, 1.0));
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere5.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo5);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo5);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere5.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//    //
//
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.47f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.0, 0.0, 1.0));
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere6.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo6);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo6);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere6.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//
////
//
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.36f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.0, 0.0, 1.0));
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere7.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo7);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo7);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere7.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//    //
//
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.25f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.0, 0.0, 1.0));
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere8.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo8);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo8);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere8.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//
//    //
//
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.14f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.0, 0.0, 1.0));
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere9.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo9);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo9);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere9.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//    trans = glm::mat4(1.0f);
//    trans = glm::translate(trans, glm::vec3(0.03f, 0.0f, 0.0f));
//    trans = glm::scale(trans, glm::vec3(0.1f, 0.1f, 0.1f));
//    trans = glm::rotate(trans, translate, glm::vec3(0.0, 0.0, 1.0));
//
//    glUniformMatrix4fv(transAttrib, 1, GL_FALSE, glm::value_ptr(trans));
//
//    glDrawElements(GL_TRIANGLES, sphere10.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo10);
//    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo10);
//    //give the translate value
//    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, sphere10.getInterleavedStride(), BUFFER_OFFSET(0));
//
//
//
//




    glutSwapBuffers();
}

void idle() {
    translate += factor;
    scale += factor;
    
    rotatex += factor;

    if (translate > 1.0f) {
        factor = -0.0005;
    }
    else if (translate < -1.0f) {
        factor = 0.0005;
    }



    if (rotatex > 1.0f) {
        factor = -0.005;
    }
    else if (translate < -1.0f) {
        factor = 0.005;
    }

    glutPostRedisplay();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(512, 512);
    glutInitContextVersion(3, 2);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutCreateWindow("Sphere");
    glewInit();
    init();

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutMainLoop();
    return 0;
}
